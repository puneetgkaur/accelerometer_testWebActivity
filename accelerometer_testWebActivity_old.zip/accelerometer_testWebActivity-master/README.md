accelerometer_testWebActivity
=============================

sugar test web activity to test the accelerometer plugin
